const e=`tools:
  token-generator:
    title: Token generator
    description: Generate random string with the chars you want, uppercase or lowercase letters, numbers and/or symbols.

    uppercase: Uppercase (ABC...)
    lowercase: Lowercase (abc...)
    numbers: Numbers (123...)
    symbols: Symbols (!-;...)
    length: Length
    tokenPlaceholder: 'The token...'
    copied: Token copied to the clipboard
    button:
      copy: Copy
      refresh: Refresh`;export{e as default};
