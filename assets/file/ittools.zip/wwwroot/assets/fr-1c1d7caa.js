const e=`tools:
  token-generator:
    title: Générateur de token
    description: >-
      Génère une chaîne aléatoire avec les caractères que vous voulez, lettres
      majuscules ou minuscules, chiffres et/ou symboles.
    uppercase: Majuscules (ABC...)
    lowercase: Minuscules (abc...)
    numbers: Chiffres (123...)
    symbols: Symboles (!-;...)
    button:
      copy: Copier
      refresh: Rafraichir
    copied: Le token a été copié
    length: Longueur
    tokenPlaceholder: Le token...
`;export{e as default};
