function r(e){try{return e(),!0}catch{return!1}}function t(e){return e?"Yes":"No"}export{t as b,r as i};
