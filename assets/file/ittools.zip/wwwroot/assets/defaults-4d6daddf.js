function a(r,t){try{return r()}catch{return t}}async function c(r,t){try{return await r()}catch{return t}}export{c as a,a as w};
