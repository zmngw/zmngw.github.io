import{a5 as e}from"./index-9864a4b0.js";const t={},r=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(r);export{a as r};
