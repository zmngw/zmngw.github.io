function n(t){return t.trim().split("").map(r=>Number.parseInt(r,16).toString(2).padStart(4,"0")).join("")}export{n as c};
