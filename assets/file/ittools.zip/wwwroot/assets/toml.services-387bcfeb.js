import{p as o}from"./toml-esm-9c5f6a1e.js";import{i as r}from"./boolean-c7e7c785.js";function a(i){return r(()=>o(i))}export{a as i};
